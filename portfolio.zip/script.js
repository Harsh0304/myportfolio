
window.addEventListener('scroll',()=>{
    document.querySelector('nav').classList.toggle('window__scroll',window.scrollY>0);
})

//============= toggle button==============>
const btnOpen= document.querySelector('#nav__toggle-open');
const btnClose= document.querySelector('#nav__toggle-close');
const navLinks=document.querySelector('.nav__links');

const openNav=()=>{
    navLinks.style.display='flex';
     btnClose.style.display='inline-block';
     btnOpen.style.display='none';
}
const closeNav=()=>{
    navLinks.style.display='none';
    btnOpen.style.display='inline-block';
     btnClose.style.display='none';
}
btnOpen.addEventListener('click',openNav)
btnClose.addEventListener('click',closeNav)
// navLinks.querySelectorAll('li a').forEach(navLink=>{
//     navLink.addEventListener('click',closeNav)
// })


// ====================tab=====================>
const tabBtns=document.querySelector('.tab__btns');
const btn=document.querySelectorAll('.tab__btn');
const content=document.querySelectorAll('.tab__content');

tabBtns.addEventListener('click',(e)=>{
    const clicked=e.target;
    console.log(clicked);
    if(!clicked)
     return
    btn.forEach((t)=>t.classList.remove('tab__btn__active'));
    clicked.classList.add('tab__btn__active');
    content.forEach(c=>c.classList.remove('tab__content__active'))
    document.querySelector(`.tab__content--${clicked.dataset.tab}`).classList.add('tab__content__active')
})
